<?php $__env->startSection('title' , 'post'); ?>

<?php $__env->startSection('content'); ?>

 <!-- strat landing -->
 <div class="landing-page d-flex justify-content-center align-items-center" style="

    background-image: url(<?php echo e(Voyager::image($post->image)); ?>);
    background-size: cover;
    min-height: calc(100vh - 1px);">
    <div class="container text-center blur rounded p-3">
        <h1><?php echo e($post->title); ?></h1>
        <p class="fs-6 text-black-50 mb-5"><?php echo e($post->excerpt); ?></p>
        <a href="#go"><button>Let's see the danger 👇</button></a>
    </div>
   </div>
  <!-- end landing -->

  
  <div class="container pt-5 pb-5" id="go">
    <?php echo $post->body; ?>

  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.boot-bree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Desktop/Laravle Project/nasa/resources/views/post.blade.php ENDPATH**/ ?>